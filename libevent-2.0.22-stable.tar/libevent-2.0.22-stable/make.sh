#!/bin/bash

./configure

make -j 8

make install
